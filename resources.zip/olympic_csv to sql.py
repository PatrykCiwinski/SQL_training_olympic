import pandas as pd
import sqlalchemy as sql

conn_name='postgresql://postgres:admin@localhost/olympic'
db=sql.create_engine(conn_name)
conn=db.connect()

files=['athlete_events','noc_regions']

for file in files:
    df=pd.read_csv(f'C:/Users/patry/OneDrive/Desktop/SQL training/sql olympic/{file}.csv')
    df.to_sql(file,con=conn,if_exists='replace',index=False)

